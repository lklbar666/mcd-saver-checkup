# 本轮核价，直接生成餐单报告

[免安装历史体验](https://sam-hui-dot.github.io/mcd-saver-checkup/) · [脱敏历史报告示例](https://sam-hui-dot.github.io/mcd-saver-checkup/example-report.html)

AI照常根据当前门店菜单、详情和优惠准备最多三份完整候选。用户只需要告诉它预算、门店和偏好。

```powershell
python skills/mcd-saver-checkup/scripts/quote_audits.py private/audit-plan.json --use-workbuddy-config --records-dir private/run-001
```

成功报价会自动保存为 `private/run-001/comparison.json`，同时生成 `audit-report.html`。打开HTML即可调整预算、查看整单应付与余量、比较餐品差异并复制结果。打开页面不联网，不触发新的核价请求。记录目录必须是新的空子目录，避免覆盖已有证据。

只有本轮通过金额、组成与偏好检查的报价进入页面；之前成功而后续失败时，报告保留成功结果，并标明未纳入数量。具体失败原因留在本机比较JSON和终端输出。全部失败时显示没有有效报价，不填零元餐单。

HTML模板缺失或报告写入失败时，有效报价仍会正常输出，只增加本地导出提示；比较JSON会独立尝试保存。JSON写入失败时也不会把已有报价标成无效，应保留终端输出。导出故障不触发重新核价，业务接口失败的停止规则保持不变。

页面只比较已有完整报价。更换餐品仍须重新调用官方核价；调预算不生成新组合。超过本项目15分钟比较期限后，真实报告会提示重新核价，并保留历史记录供查看。这个期限不是官方报价承诺。

## 差价怎么看

相邻餐单按整单应付金额从低到高比较，分别列出增加、减少和保持不变的餐品份数；套餐容器不计入实际份数，编码相同但特调不同也不会算成同一选项。优惠条件不同时会单独提示。

例如，一份¥14.90的汉堡饮料组合与¥22.90的三件套，可能同时更换汉堡并增加薯条。报告会列出这些变化，而不会把整单¥8差价称为薯条售价。

## 配置或服务错误

连接器名称不必叫 `mcd-mcp`，脚本按官方地址 `https://mcp.mcd.cn` 查找；存在多个匹配项时，用 `--server-key`选择。认证仅从环境变量或用户明确指定的本机WorkBuddy配置读取。

| 提示 | 处理 |
|---|---|
| 未找到配置或官方连接器 | 检查WorkBuddy本机连接器，或设置本机环境变量 |
| 认证缺失或仍是占位符 | 只在本机确认Authorization与有效Token |
| 401/403 | 检查激活、Token有效性与访问权限 |
| 429 | 本轮停止，不连续重试，稍后另开一轮 |
| 超时、网络错误或5xx | 本轮停止；检查网络或等待服务恢复 |

脚本不把认证头、HTTP响应正文或任意远端错误消息拼入提示。

## 报告里保留什么

报告只提取餐单名称、实际组成与数量、整单金额、优惠条件、门店与时间。不嵌入原始请求、认证、券实例编码、原始响应、请求哈希或本机文件引用。用户本机报告仍包含所选餐品、门店与时间，分享前应先脱敏；不会自动上传。仓库和在线体验中的案例已隐藏门店与核价时段。

已有本地核价JSON也可离线生成新报告：

```powershell
python skills/mcd-saver-checkup/scripts/report_audits.py private/live-quotes.json --output private/report-002.html
```

这个输入采用 [本地报价格式](../skills/mcd-saver-checkup/references/quote-format.md)，不是未经处理的官方响应或 `comparison.json`。默认拒绝过期live报价；已生成报告本身可以作为历史记录查看。目标文件已存在时拒绝覆盖。

恢复批量入口已经保存的 `comparison.json`，使用独立的历史恢复模式：

```powershell
python skills/mcd-saver-checkup/scripts/report_audits.py private/run-001/comparison.json --from-comparison --output private/restored-report.html
```

该模式不联网、不读取认证；重新检查金额、组成格式和时间，按保存的预算重新计算余量，保留原核价时间。页面明确标注“历史比较结果 · 未重新核价”，不把旧记录恢复成当前售价。它不能验证本地文件是否被改动，也不能补出保存结果中未包含的原始调用或偏好约束。目标文件存在时仍拒绝覆盖。

## 安装和升级

`install.ps1`先在用户技能目录内暂存干净的新版本，忽略源包里的 `private/`、Python缓存和`.pyc`；已有技能中的 `private/`记录会保留到新版本。随后将完整旧技能移动到 `~/.workbuddy/skill-backups/`，再切换新目录，避免覆盖合并留下废弃程序文件。切换失败时恢复旧技能；未完成的暂存目录保留供检查，不自动删除旧版本。

通常直接运行 `./install.ps1`。`-ProfileDirectory`用于显式指定配置根目录；离线验收使用临时目录，不修改系统HOME、连接器或真实用户配置。真实WorkBuddy的技能发现仍须在用户客户端新开会话后确认。

## 已完成的验证

42项Python纯离线回归和13组JavaScript模拟DOM场景通过。真实批量入口完成三份核价与自动报告生成，换无糖可乐后另行核价成功，见 [公开摘要](../examples/batch-verification.md)。该店当时无可用券，因此本轮没有真实带券案例。

现有Edge插件中完成8组实际键盘预算输入、历史饮料切换、差价展示和375/320 CSS像素容器检查，未横向溢出；实际报告的“查看可复制文本”内容包含当前预算、真实餐品与差价。复制按钮显示成功，但插件剪贴板读回为空，因此未独立确认系统剪贴板内容。两段自动复制与手动回退另有离线模拟覆盖。文件双击模式的专属剪贴板权限、实际安装未验证。
